#include <configs/xilinx_zynqmp.h>
#include <configs/platform-auto.h>
